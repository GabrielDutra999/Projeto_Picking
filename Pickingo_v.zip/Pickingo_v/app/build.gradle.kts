plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
}

android {
    namespace = "com.example.pickngo_v" // Corrigido para o namespace correto

    compileSdk = 35 // Usei 34 com base no seu targetSdk, ajuste se necessário

    defaultConfig {
        applicationId = "com.example.pickngo_v" // O ID único da sua aplicação
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        vectorDrawables {
            useSupportLibrary = true
        }
    }

    // Você pode adicionar outros blocos de configuração Android aqui, como:
    // buildTypes { ... }
    // compileOptions { ... }
    // kotlinOptions { ... }
}

dependencies {
    // Dependências de implementação necessárias para o seu aplicativo
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.appcompat)
    implementation(libs.material)
    implementation(libs.androidx.constraintlayout)

    // Google Location Services (para rastreamento futuro)
    implementation(libs.play.services.location)

    // Dependências de teste (geralmente adicionadas aqui)
    testImplementation(libs.junit)
    androidTestImplementation(libs.androidx.junit)
    androidTestImplementation(libs.androidx.espresso.core)
}
