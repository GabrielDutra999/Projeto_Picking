import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, TouchableOpacity, FlatList, ImageBackground } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

const colors = {
  background: '#DFDDDC',
  primary: '#DC5D07',
  secondary: '#DB6D1C',
  text: '#242423',
  accent: '#7EABE6',
  card: '#C6CEDC'
};

const ApresentacaoScreen = ({ continuar }) => {
  return (
    <ImageBackground
      source={require('./Picking_img.jpg')}
      style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}
      imageStyle={{ opacity: 0.3 }}
    >
      <View style={{ padding: 20, backgroundColor: 'rgba(255,255,255,0.8)', borderRadius: 10 }}>
        <Text style={{ fontSize: 24, fontWeight: 'bold', color: colors.text, marginBottom: 10 }}>Quem Somos</Text>
        <Text style={{ fontSize: 16, color: colors.text, marginBottom: 20 }}>
          Somos uma solução voltada para pequenos comerciantes e centros de distribuição que precisam otimizar o tempo e reduzir falhas humanas no processo de separação de pedidos.
        </Text>
        <TouchableOpacity onPress={continuar} style={{ backgroundColor: colors.primary, padding: 10, borderRadius: 10 }}>
          <Text style={{ color: '#fff' }}>Começar</Text>
        </TouchableOpacity>
      </View>
    </ImageBackground>
  );
};

const LoginScreen = ({ onLogin, trocarTela }) => {
  const [email, setEmail] = useState('');
  const [senha, setSenha] = useState('');

  const handleLogin = async () => {
    try {
      const data = await AsyncStorage.getItem('usuarios');
      const usuarios = data ? JSON.parse(data) : [];
      const usuarioValido = usuarios.find(u => u.email === email && u.senha === senha);
      if (usuarioValido) {
        await AsyncStorage.setItem('username', usuarioValido.nome);
        onLogin(usuarioValido.nome);
      } else {
        alert('Email ou senha inválidos.');
      }
    } catch (error) {
      alert('Erro ao tentar logar.');
    }
  };

  return (
    <View style={{ flex: 1, backgroundColor: colors.background, justifyContent: 'center', alignItems: 'center' }}>
      <Text style={{ fontSize: 24, color: colors.text, marginBottom: 20 }}>Login</Text>
      <TextInput
        placeholder="Email"
        value={email}
        onChangeText={setEmail}
        style={{ backgroundColor: colors.card, padding: 10, width: '80%', borderRadius: 10, marginBottom: 10 }}
      />
      <TextInput
        placeholder="Senha"
        secureTextEntry
        value={senha}
        onChangeText={setSenha}
        style={{ backgroundColor: colors.card, padding: 10, width: '80%', borderRadius: 10, marginBottom: 20 }}
      />
      <TouchableOpacity onPress={handleLogin} style={{ backgroundColor: colors.primary, padding: 10, borderRadius: 10, marginBottom: 10 }}>
        <Text style={{ color: '#fff' }}>Entrar</Text>
      </TouchableOpacity>
      <TouchableOpacity onPress={trocarTela}>
        <Text style={{ color: colors.accent }}>Criar uma conta</Text>
      </TouchableOpacity>
    </View>
  );
};

const CadastroScreen = ({ trocarTela }) => {
  const [email, setEmail] = useState('');
  const [senha, setSenha] = useState('');
  const [nome, setNome] = useState('');

  const handleCadastro = async () => {
    if (email && senha && nome) {
      try {
        const data = await AsyncStorage.getItem('usuarios');
        const usuarios = data ? JSON.parse(data) : [];
        usuarios.push({ email, senha, nome });
        await AsyncStorage.setItem('usuarios', JSON.stringify(usuarios));
        alert('Conta criada com sucesso!');
        trocarTela();
      } catch (error) {
        alert('Erro ao salvar dados de cadastro.');
      }
    } else {
      alert('Preencha todos os campos.');
    }
  };

  return (
    <View style={{ flex: 1, backgroundColor: colors.background, justifyContent: 'center', alignItems: 'center' }}>
      <Text style={{ fontSize: 24, color: colors.text, marginBottom: 20 }}>Criar Conta</Text>
      <TextInput
        placeholder="Nome"
        value={nome}
        onChangeText={setNome}
        style={{ backgroundColor: colors.card, padding: 10, width: '80%', borderRadius: 10, marginBottom: 10 }}
      />
      <TextInput
        placeholder="Email"
        value={email}
        onChangeText={setEmail}
        style={{ backgroundColor: colors.card, padding: 10, width: '80%', borderRadius: 10, marginBottom: 10 }}
      />
      <TextInput
        placeholder="Senha"
        secureTextEntry
        value={senha}
        onChangeText={setSenha}
        style={{ backgroundColor: colors.card, padding: 10, width: '80%', borderRadius: 10, marginBottom: 20 }}
      />
      <TouchableOpacity onPress={handleCadastro} style={{ backgroundColor: colors.secondary, padding: 10, borderRadius: 10, marginBottom: 10 }}>
        <Text style={{ color: '#fff' }}>Cadastrar</Text>
      </TouchableOpacity>
      <TouchableOpacity onPress={trocarTela}>
        <Text style={{ color: colors.accent }}>Voltar ao login</Text>
      </TouchableOpacity>
    </View>
  );
};

const PedidoItem = ({ item }) => (
  <View style={{ backgroundColor: colors.card, padding: 10, marginVertical: 5, borderRadius: 10 }}>
    <Text style={{ color: colors.text }}>Pedido: {item.id}</Text>
    <Text style={{ color: colors.text }}>Código: {item.codigo}</Text>
    <Text style={{ color: colors.text }}>Item: {item.nome}</Text>
    <Text style={{ color: colors.text }}>Quantidade: {item.qtd}</Text>
  </View>
);

const PedidoScreen = ({ username }) => {
  const [pedidos, setPedidos] = useState([
    { id: '001', codigo: '2917192', nome: 'Produto A', qtd: 3 },
    { id: '002', codigo: '8736209', nome: 'Produto B', qtd: 1 },
    { id: '003', codigo: '1729384', nome: 'Produto C', qtd: 5 },
    { id: '004', codigo: '3849201', nome: 'Produto D', qtd: 2 },
    { id: '005', codigo: '7643108', nome: 'Produto E', qtd: 4 },
    { id: '006', codigo: '9182736', nome: 'Produto F', qtd: 6 },
    { id: '007', codigo: '5647382', nome: 'Produto G', qtd: 3 },
    { id: '008', codigo: '8374659', nome: 'Produto H', qtd: 7 },
    { id: '009', codigo: '2039485', nome: 'Produto I', qtd: 2 },
    { id: '010', codigo: '6655443', nome: 'Produto J', qtd: 1 }
  ]);

  const [codigoBusca, setCodigoBusca] = useState('');
  const [resultadoBusca, setResultadoBusca] = useState(null);

  const buscarPedido = () => {
    const resultado = pedidos.find(p => p.codigo === codigoBusca);
    setResultadoBusca(resultado || null);
  };

  return (
    <View style={{ flex: 1, backgroundColor: colors.background, padding: 20 }}>
      <Text style={{ fontSize: 20, color: colors.secondary, marginBottom: 10 }}>Olá, {username}</Text>
      <Text style={{ fontSize: 18, color: colors.text, marginBottom: 10 }}>Controle de Pedidos</Text>

      <TextInput
        placeholder="Digite o código do item"
        value={codigoBusca}
        onChangeText={setCodigoBusca}
        style={{ backgroundColor: colors.card, padding: 10, borderRadius: 10, marginBottom: 10 }}
      />
      <TouchableOpacity onPress={buscarPedido} style={{ backgroundColor: colors.accent, padding: 10, borderRadius: 10, marginBottom: 20 }}>
        <Text style={{ color: '#fff', textAlign: 'center' }}>Buscar</Text>
      </TouchableOpacity>

      {resultadoBusca ? (
        <PedidoItem item={resultadoBusca} />
      ) : codigoBusca !== '' ? (
        <Text style={{ color: colors.text }}>Nenhum item encontrado.</Text>
      ) : (
        <FlatList
          data={pedidos}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => <PedidoItem item={item} />}
        />
      )}
    </View>
  );
};

export default function App() {
  const [logado, setLogado] = useState(false);
  const [username, setUsername] = useState('');
  const [telaCadastro, setTelaCadastro] = useState(false);
  const [telaInicial, setTelaInicial] = useState(true);

  useEffect(() => {
    const recuperarLogin = async () => {
      const nome = await AsyncStorage.getItem('username');
      if (nome) {
        setUsername(nome);
        setLogado(true);
      }
    };
    recuperarLogin();
  }, []);

  const handleLogin = (nome) => {
    setUsername(nome);
    setLogado(true);
  };

  if (telaInicial) {
    return <ApresentacaoScreen continuar={() => setTelaInicial(false)} />;
  }

  if (logado) {
    return <PedidoScreen username={username} />;
  }

  return telaCadastro
    ? <CadastroScreen trocarTela={() => setTelaCadastro(false)} />
    : <LoginScreen onLogin={handleLogin} trocarTela={() => setTelaCadastro(true)} />;
}
