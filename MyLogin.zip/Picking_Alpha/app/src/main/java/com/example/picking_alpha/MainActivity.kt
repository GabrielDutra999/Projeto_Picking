package com.example.pickingapp

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var etCodigo: EditText
    private lateinit var btnBuscar: Button
    private lateinit var tvInfo: TextView
    private lateinit var spinner: Spinner
    private lateinit var btnAtualizar: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main) // <- aqui corrigido

        etCodigo = findViewById(R.id.etCodigoProduto)
        btnBuscar = findViewById(R.id.btnBuscar)
        tvInfo = findViewById(R.id.tvInfoProduto)
        spinner = findViewById(R.id.spinnerStatus)
        btnAtualizar = findViewById(R.id.btnAtualizarStatus)

        btnBuscar.setOnClickListener {
            val codigo = etCodigo.text.toString().trim()
            if (codigo.isEmpty()) {
                Toast.makeText(this, "Digite um código!", Toast.LENGTH_SHORT).show()
            } else {
                tvInfo.text = "Produto: CX1234\nLocalização: A2-3B\nPeso: 12kg"
            }
        }

        btnAtualizar.setOnClickListener {
            val status = spinner.selectedItem.toString()
            if (status == "Selecionar Status") {
                Toast.makeText(this, "Selecione um status!", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Status atualizado para: $status", Toast.LENGTH_SHORT).show()
            }
        }
    }